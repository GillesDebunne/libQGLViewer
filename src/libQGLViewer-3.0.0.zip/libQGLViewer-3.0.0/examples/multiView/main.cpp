/**********************************************************************

Copyright (C) 2002-2025 Gilles Debunne. All rights reserved.

This file is part of the QGLViewer library version 3.0.0.

https://gillesdebunne.github.io/libQGLViewer - contact@libqglviewer.com

This file is part of a free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

**********************************************************************/

#include "multiView.h"
#include <qapplication.h>
#include <qsplitter.h>

int main(int argc, char **argv) {
  QApplication application(argc, argv);

  // Create Splitters
  QSplitter *hSplit = new QSplitter(Qt::Vertical);
  QSplitter *vSplit1 = new QSplitter(hSplit);
  QSplitter *vSplit2 = new QSplitter(hSplit);

  // Create the scene
  Scene *s = new Scene();

  // Instantiate the viewers.
  Viewer side(s, 0, vSplit1);
  Viewer top(s, 1, vSplit1);
  Viewer front(s, 2, vSplit2);
  Viewer persp(s, 3, vSplit2);

  hSplit->setWindowTitle("multiView");

  // Set main QSplitter as the main widget.
  hSplit->show();

  return application.exec();
}
