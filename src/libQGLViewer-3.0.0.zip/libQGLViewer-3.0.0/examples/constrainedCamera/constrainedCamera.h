/**********************************************************************

Copyright (C) 2002-2025 Gilles Debunne. All rights reserved.

This file is part of the QGLViewer library version 3.0.0.

https://gillesdebunne.github.io/libQGLViewer - contact@libqglviewer.com

This file is part of a free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

**********************************************************************/

#include <QGLViewer/qglviewer.h>

class Viewer : public QGLViewer {
protected:
  virtual void init();
  virtual void draw();
  virtual QString helpString() const;
  virtual void keyPressEvent(QKeyEvent *);

  void displayText();
  void displayType(const qglviewer::AxisPlaneConstraint::Type type, const int x,
                   const int y, const char c);
  void displayDir(const unsigned short dir, const int x, const int y,
                  const char c);

private:
  int transDir;
  int rotDir;

  static qglviewer::AxisPlaneConstraint::Type nextTranslationConstraintType(
      const qglviewer::AxisPlaneConstraint::Type &type);
  static qglviewer::AxisPlaneConstraint::Type
  nextRotationConstraintType(const qglviewer::AxisPlaneConstraint::Type &type);

  void changeConstraint();
  qglviewer::AxisPlaneConstraint *constraints[2];
  unsigned short activeConstraint;
};
