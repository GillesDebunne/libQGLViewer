var searchData=
[
  ['type_994',['Type',['../classqglviewer_1_1Camera.html#a1d1cfd8ffb84e947f82999c682b666a7',1,'qglviewer::Camera::Type()'],['../classqglviewer_1_1AxisPlaneConstraint.html#a1d1cfd8ffb84e947f82999c682b666a7',1,'qglviewer::AxisPlaneConstraint::Type()']]]
];
