/**********************************************************************

Copyright (C) 2002-2025 Gilles Debunne. All rights reserved.

This file is part of the QGLViewer library version 3.0.0.

https://gillesdebunne.github.io/libQGLViewer - contact@libqglviewer.com

This file is part of a free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

**********************************************************************/

#include <QGLViewer/camera.h>

class CullingCamera : public qglviewer::Camera {
public:
  void computeFrustumPlanesEquations() const {
    getFrustumPlanesCoefficients(planeCoefficients);
  }

  float distanceToFrustumPlane(int index, const qglviewer::Vec &pos) const;
  bool sphereIsVisible(const qglviewer::Vec &center, float radius) const;
  bool aaBoxIsVisible(const qglviewer::Vec &p1, const qglviewer::Vec &p2,
                      bool *entirely = NULL) const;

private:
  // F r u s t u m   p l a n e s
  mutable GLdouble planeCoefficients[6][4];
};
